
	<li data-bind="css:{selected:$root.PageId()==_id()}" class="dropdown">
        <a style="cursor:pointer" class="dropdown-toggle" data-toggle="dropdown">Page</a>
        <ul class="dropdown-menu" role="menu">
        	<li>
        		<a href="#">Blank</a>
        	</li>
        </ul>
    </li>