go build -o colony-test-read-data-2
mv colony-test-read-data-2 $EC_APP_PATH/web
cd $EC_APP_PATH/web
./colony-test-read-data-2
